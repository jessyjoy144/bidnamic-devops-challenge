from flask import Flask,request,render_template
application = Flask(__name__)

@application.route('/')
def pretend():
    return 'Lets pretend this function eats lots of resources!'
if __name__ == '_main_' :
    application.run()
    